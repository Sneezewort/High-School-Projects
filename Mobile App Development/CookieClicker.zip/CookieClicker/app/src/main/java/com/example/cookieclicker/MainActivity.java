package com.example.cookieclicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    ImageView image;
    ScaleAnimation animation;
    TranslateAnimation aPlus;
    AlphaAnimation fPlus;
    AnimationSet set;
    RotateAnimation aC;
    TranslateAnimation dX;
    TextView water;
    ConstraintLayout layout;
    Button upgrade1;
    Button upgrade2;
    Drawable hydrant;
    Drawable charity;
    Drawable wDrop;
    int crate = 1;
    TextView ratePlus;
    TextView gps;
    ImageView hyd;
    ImageView drop;
    ImageView cha;
    TextView chars;
    int charC = 0;
    int x;
    int y;
    float[] click = new float[2];
    Context c = this;
    AtomicInteger rate = new AtomicInteger(0);
    int count = 0;
    int rateSec = 0;
    passive passive;
    boolean hydB = false;
    int randX;
    int randY;
    AnimationDrawable back1;
    AnimationDrawable back2;
    ConstraintLayout constraintLayout;
    int angle = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        constraintLayout = findViewById(R.id.id_cLayout);
        back2 = (AnimationDrawable) getResources().getDrawable(R.drawable.gradient_list2);
        back2.setEnterFadeDuration(2000);
        back2.setExitFadeDuration(4000);
        if(rateSec<5) {
            back1 = (AnimationDrawable) getResources().getDrawable(R.drawable.gradient_list);
            back1.setEnterFadeDuration(2000);
            back1.setExitFadeDuration(4000);
            constraintLayout.setBackground(back1);
            back1.start();
        }
        image = findViewById(R.id.id_image);
        water = findViewById(R.id.id_water);
        layout = findViewById(R.id.id_layout);
        upgrade1 = findViewById(R.id.id_upgrade1);
        gps = findViewById(R.id.id_rate);
        upgrade1.setTransformationMethod(null);
        upgrade1.setTextSize(20);
        hydrant = getResources().getDrawable(R.drawable.firehydrant);
        wDrop = getResources().getDrawable(R.drawable.waterdrop);
        upgrade1.setCompoundDrawablesWithIntrinsicBounds(hydrant, null, null, null);
        upgrade2 = findViewById(R.id.id_upgrade2);
        upgrade2.setTransformationMethod(null);
        upgrade2.setTextSize(20);
        charity = getResources().getDrawable(R.drawable.charity);
        upgrade2.setCompoundDrawablesWithIntrinsicBounds(charity, null, null, null);
        animation = new ScaleAnimation(1.0f, 1.1f, 1.0f, 1.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.2f);
        animation.setDuration(200);
        aC = new RotateAnimation(0, 360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        aC.setInterpolator(new LinearInterpolator());
        aC.setRepeatCount(Animation.INFINITE);
        randX = (int)(Math.random()*2000)-1000;
        randY = (int)(Math.random()*2000)-1000;
        dX = new TranslateAnimation(0, randX, 0, randY);
        dX.setDuration(2000);
        dX.setRepeatCount(Animation.INFINITE);
        passive = new passive();
        passive.start();
        if(cha != null) {
            chars = new TextView(c);
            chars.setId(View.generateViewId());
            chars.setText("x"+charC);
            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
            chars.setLayoutParams(params);
            chars.setX(600);
            chars.setY(200);
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(layout);
            constraintSet.connect(hyd.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
            constraintSet.connect(hyd.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
            constraintSet.connect(hyd.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
            constraintSet.connect(hyd.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
            constraintSet.applyTo(layout);
            layout.addView(chars);
        }
        upgrade1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(upgrade1.getText().toString().equals("Firefighters")) {
                    upgrade1.setText("Clicking gains 500% of Gallons Per Second\n[50 Gallons]");
                    upgrade1.setTextSize(13);
                }
                else if (rate.get()<50) {
                    upgrade1.setText("Insufficient Funds\n[Need "+(50-rate.get())+" more Gallons]");
                    upgrade1.setTextSize(13);
                    CountDownTimer timer = new CountDownTimer((3) * 1000, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                        }

                        @Override
                        public void onFinish() {
                            upgrade1.setText("Firefighters");
                            upgrade1.setTextSize(20);
                        }

                    }.start();
                }
                else {
                    //w -= 50;
                    rate.getAndAdd(-50);
                    water.setText(rate.get() + " Gallons");
                    crate = crate*5;
                    upgrade1.setVisibility(View.GONE);
                    hyd = new ImageView(c);
                    hyd.setId(View.generateViewId());
                    hyd.setImageDrawable(hydrant);
                    ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    hyd.setLayoutParams(params);
                    hyd.setX(-300);
                    //-630
                    hyd.setY(180);
                    hyd.setElevation(1);
                    layout.addView(hyd);
                    ConstraintSet constraintSet = new ConstraintSet();
                    constraintSet.clone(layout);
                    constraintSet.connect(hyd.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                    constraintSet.connect(hyd.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                    constraintSet.connect(hyd.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                    constraintSet.connect(hyd.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                    constraintSet.applyTo(layout);
                    hydB = true;
                }
            }
        });
        upgrade2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(upgrade2.getText().toString().equals("Charity")) {
                    upgrade2.setText("Increases Gallons per Second by 1\n[20 Gallons]");
                    upgrade2.setTextSize(14);
                }
                else if (rate.get()<20) {
                    upgrade2.setText("Insufficient Funds\n[Need "+(20-rate.get())+" more Gallons]");
                    upgrade2.setTextSize(13);
                    CountDownTimer timer = new CountDownTimer((3) * 1000, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {

                        }

                        @Override
                        public void onFinish() {
                            upgrade2.setText("Charity");
                            upgrade2.setTextSize(20);
                        }
                    }.start();
                }
                else {
                    if(rateSec == 0) {
                        cha = new ImageView(c);
                        cha.setId(View.generateViewId());
                        cha.setImageDrawable(charity);
                        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                        cha.setLayoutParams(params);
                        cha.setX(600);
                        cha.setY(180);
                        layout.addView(cha);
                        ConstraintSet constraintSet = new ConstraintSet();
                        constraintSet.clone(layout);
                        constraintSet.connect(cha.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                        constraintSet.connect(cha.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                        constraintSet.connect(cha.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                        constraintSet.connect(cha.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                        constraintSet.applyTo(layout);
                    }
                    rate.getAndAdd(-20);
                    charC++;
                    water.setText(rate.get() + " Gallons");
                    rateSec++;
                    gps.setText(rateSec + " GPS");
                    upgrade2.setText("Charity");
                    if(rateSec>=5) {
                        constraintLayout.setBackground(back2);
                        back2.start();
                    }
                }
            }
        });
        image.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                x = (int)event.getX();
                y = (int)event.getY();
                return false;
            }
        });
        image.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    click[0] = event.getX();
                    click[1] = event.getY();
                }
                return false;
            }
        });
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v.startAnimation(animation);
                rate.getAndAdd(crate);
                water.setText(rate + " Gallons");
                ratePlus = new TextView(c);
                ratePlus.setId(View.generateViewId());
                ratePlus.setText("+ "+crate);
                ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                ratePlus.setLayoutParams(params);
                ratePlus.setX(click[0] - 300);
                ratePlus.setY(click[1]+50);
                ratePlus.setTextSize(45);
                ratePlus.setTextColor(Color.BLUE);
                ratePlus.setTypeface(null, Typeface.BOLD);
                ViewGroup.LayoutParams params1 = ratePlus.getLayoutParams();
                params1.height = 200;
                params1.width = 200;
                ratePlus.setLayoutParams(params1);
                layout.addView(ratePlus);
                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(layout);
                constraintSet.connect(ratePlus.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                constraintSet.connect(ratePlus.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                constraintSet.connect(ratePlus.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                constraintSet.connect(ratePlus.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                constraintSet.applyTo(layout);
                aPlus = new TranslateAnimation(0 , 0, 0, -600);
                aPlus.setDuration(500);
                fPlus = new AlphaAnimation(1, 0);
                fPlus.setDuration(500);
                set = new AnimationSet(false);
                set.addAnimation(aPlus);
                set.addAnimation(fPlus);
                ratePlus.startAnimation(set);
                ratePlus.setVisibility(View.INVISIBLE);
                if(hydB) {
                    randX = (int) (Math.random() * 2000) - 1000;
                    randY = (int) (Math.random() * 2000) - 1000;
                    dX = new TranslateAnimation(0, randX, 0, randY);
                    dX.setDuration(2000);
                    drop = new ImageView(c);
                    drop.setId(View.generateViewId());
                    drop.setImageDrawable(wDrop);
                    ConstraintLayout.LayoutParams params2 = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    drop.setLayoutParams(params2);
                    drop.setX(-300);
                    drop.setY(180);
                    drop.setScaleX(0.05f);
                    drop.setScaleY(0.05f);
                    drop.setElevation(0);
                    drop.startAnimation(dX);
                    layout.addView(drop);
                    ConstraintSet constraintSet1 = new ConstraintSet();
                    constraintSet1.clone(layout);
                    constraintSet1.connect(drop.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                    constraintSet1.connect(drop.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                    constraintSet1.connect(drop.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                    constraintSet1.connect(drop.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                    constraintSet1.applyTo(layout);
                    drop.startAnimation(dX);
                }
            }
        });
        dX.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                if(drop != null)
                    drop.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if(drop != null)
                    drop.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
    public class passive extends Thread{
        @Override
        public void run(){
            while (true) {
                try {
                    if(rateSec!=0)
                        TimeUnit.NANOSECONDS.sleep(1000000000/rateSec);
                    else
                        Thread.sleep(1000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if(rateSec != 0) {
                    rate.getAndAdd(1);
                    angle++;
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(rateSec!=0) {
                            water.setText(rate.get() + " Gallons");
                            cha.animate().rotation(cha.getRotation()+10).start();
                        }
                    }
                });

            }

        }
    }
}

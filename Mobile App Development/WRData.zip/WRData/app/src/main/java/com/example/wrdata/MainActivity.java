package com.example.wrdata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    String dataToWrite = "1";
    String file = "file.txt";
    File fDir;
    File fil;
    String s;
    String temp = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            fDir = this.getFilesDir();
            if (fDir.canWrite()) {
                fil = new File(fDir, file);
            }
            OutputStreamWriter writer = new OutputStreamWriter(openFileOutput(file, Context.MODE_PRIVATE));
            writer.write(dataToWrite);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput(file)));
            while ((s = bufferedReader.readLine()) != null) {
                temp += s;
            }
            Toast.makeText(this, temp, Toast.LENGTH_SHORT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

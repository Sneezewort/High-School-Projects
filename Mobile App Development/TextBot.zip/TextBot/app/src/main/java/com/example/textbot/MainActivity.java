package com.example.textbot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    BroadcastReceiver smsReceiver;
    SmsManager smsManager = SmsManager.getDefault();
    SmsMessage[] messages;
    String str = "";
    String response = "hello";
    Context context = this;
    TextView textstate;
    int state = 0;
    String[][] states = new String[4][6];
    int ran = 0;
    boolean contains = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textstate = findViewById(R.id.id_state);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.RECEIVE_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, 1000);
        }
        states[0][0] = "Hello";
        states[0][1] = "hello";
        states[0][2] = "Hi";
        states[0][3] = "hi";
        states[1][0] = "Pepperoni";
        states[1][1] = "pepperoni";
        states[1][2] = "Plain";
        states[1][3] = "plain";
        states[1][4] = "Cheese";
        states[1][5] = "cheese";
        states[2][0] = "cash";
        states[2][1] = "Cash";
        states[2][2] = "Credit";
        states[2][3] = "credit";

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 1000) {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
            else
                finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        smsReceiver = new smsReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(smsReceiver, filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(smsReceiver);
    }
    private final Handler msgHandler = new Handler() {
    };
    public Runnable getMessageSend(final String mes) {
        Runnable messageSend = new Runnable() {
            @Override
            public void run() {
                if(state == 0) {
                    for(int i=0; i<4; i++) {
                        Log.d("TAG", mes);
                        Log.d("TAG", states[state][i]);
                        if(mes.toLowerCase().contains(states[state][i])) {
                            response = "Hello!";
                            smsManager.sendTextMessage(messages[0].getOriginatingAddress(), null, response, null, null);
                            new Timer().schedule(
                                    new TimerTask(){

                                        @Override
                                        public void run(){

                                        }

                                    }, 3000);
                            response = "This is the Corona Pizza Delivery Service, what type of pizza would you like to order? We have very limited resources.";
                            contains = true;
                            state++;
                            textstate.setText("Choosing Purchase State");
                            break;
                        }
                        else if (!contains){
                            ran = (int)(Math.random()*3);
                            if (ran == 0)
                                response = "I think you have the wrong number";
                            else if (ran == 1)
                                response = "Wrong number";
                            else if (ran == 2)
                                response = "Do you need help?";
                            textstate.setText("Confused Greeting State");
                        }
                    }
                }
                else if(state == 1) {
                    for(int i=0; i<6; i++) {
                        Log.d("TAG", mes);
                        Log.d("TAG", states[state][i]);
                        if(mes.toLowerCase().contains(states[state][i])) {
                            Log.d("RESPONSE: ", states[state][i]);
                            ran = (int)(Math.random()*2);
                            if(ran == 0)
                                response = "Will you be paying in cash or credit?";
                            else if (ran == 1)
                                response = "We have \""+mes+"\" in stock, how will you pay?";
                            contains = true;
                            state++;
                            textstate.setText("Payment State");
                            break;
                        }
                        else if (!contains) {
                            ran = (int)(Math.random()*2);
                            if (ran == 0)
                                response = "Is this a prank?";
                            else if (ran == 1)
                                response = "We do not serve \""+mes+"\" here";
                            textstate.setText("Confused Choosing Purchase State");
                        }
                    }
                }
                else if(state == 2) {
                    for(int i=0; i<4; i++) {
                        Log.d("TAG", mes);
                        Log.d("TAG", states[state][i]);
                        if(mes.toLowerCase().contains(states[state][i]) && (i==0 || i==1)) {
                            response = "Ok, please prepare the payment when we arrive.";
                            contains = true;
                            textstate.setText("Completed State");
                            state++;
                            break;
                        }
                        else if (mes.toLowerCase().contains(states[state][i]) && (i==2 || i==3)) {
                            response = "Ok, please send the payment to **Please do not send your credit card number to any untrusted source**";
                            contains = true;
                            textstate.setText("Completed State");
                            state++;
                            break;
                        }
                        else if (!contains) {
                            ran = (int)(Math.random()*2);
                            if(ran == 0)
                                response = "We do not accept \""+mes+"\" here.";
                            else if (ran == 1)
                                response = "That is not a sufficient payment method.";
                            textstate.setText("Confused Payment State");
                        }
                    }
                }
                else if(state == 3) {
                    response = "You have already finished your business.";
                }

                Log.d("RESPONSE", "Str = " + mes);
                Log.d("RESPONSE", "Response = " + response);
                smsManager.sendTextMessage(messages[0].getOriginatingAddress(), null, response, null, null);
                contains = false;
            }
        };
        return messageSend;
    }

    public class smsReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
                Bundle bundle = intent.getExtras();
                if (bundle != null) {
                    try {
                        Object[] pdus = (Object[]) bundle.get("pdus");
                        messages = new SmsMessage[pdus.length];
                        for (int i = 0; i < pdus.length; i++) {
                            messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                            str = messages[i].getMessageBody();
                        }
                        Toast.makeText(MainActivity.this.context, str, Toast.LENGTH_SHORT).show();
                        Message hMsg = Message.obtain();
                        hMsg.obj = str;
                        hMsg.setTarget(msgHandler);
                        msgHandler.handleMessage(hMsg);
                        msgHandler.postDelayed(getMessageSend(str), 1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }
}

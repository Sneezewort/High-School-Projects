package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5;
    Button b6;
    Button b7;
    Button b8;
    Button b9;
    Button bp;
    Button bs;
    Button bm;
    Button bd;
    Button bc;
    Button b0;
    Button be;
    TextView output;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.id_button1);
        b2 = findViewById(R.id.id_button2);
        b3 = findViewById(R.id.id_button3);
        b4 = findViewById(R.id.id_button4);
        b5 = findViewById(R.id.id_button5);
        b6 = findViewById(R.id.id_button6);
        b7 = findViewById(R.id.id_button7);
        b8 = findViewById(R.id.id_button8);
        b9 = findViewById(R.id.id_button9);
        bp = findViewById(R.id.id_button_plus);
        bs = findViewById(R.id.id_button_minus);
        bm = findViewById(R.id.id_button_times);
        bd = findViewById(R.id.id_button_divide);
        bc = findViewById(R.id.id_button_clear);
        b0 = findViewById(R.id.id_button0);
        be = findViewById(R.id.id_button_equals);
        output = findViewById(R.id.id_output);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        bp.setOnClickListener(this);
        bs.setOnClickListener(this);
        bm.setOnClickListener(this);
        bd.setOnClickListener(this);
        //bc.setOnClickListener(this);
        b0.setOnClickListener(this);
        //be.setOnClickListener(this);
        bc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                output.setText("");
            }
        });
        be.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (output.getText().equals("Error")) {
                }
                else {
                    String z = "";
                    //Double out = 1.0;
                    Double x = 0.0;
                    StringTokenizer function = new StringTokenizer((String) output.getText(), "+-*/", false);
                    StringTokenizer check = new StringTokenizer((String) output.getText(), "0123456789.", false);
                    //StringTokenizer order = new StringTokenizer((String)output.getText(), "+-", false);
                    //StringTokenizer order2 = new StringTokenizer((String)output.getText(), "012345678*9/", false);
                    String[] f = new String[function.countTokens()];
                    String[] c = new String[check.countTokens()];
                    //Double[] o = new Double[order.countTokens()];
                    //String[] o2 = new String[order2.countTokens()];
                    for (int i = 0; i < f.length; i++) {
                        f[i] = function.nextToken();
                        if (f[i].charAt(0) == '0')
                            output.setText("Error");
                    }
                    for (int i = 0; i < c.length; i++) {
                        c[i] = check.nextToken();
                        if(c[i].equals("-")) {
                            f[i + 1] = "-" + f[i + 1];
                            c[i] = "+";
                        }
                    }
                    /*for(int i=0; i<o.length; i++) {
                        o[i] = Double.parseDouble(order.nextToken());
                        StringTokenizer a = new StringTokenizer(Double.toString(o[i]), "/*", false);
                        StringTokenizer b = new StringTokenizer(Double.toString(o[i]), "0124356789", false);
                        String[] a1 = new String[a.countTokens()];
                        String[] b1 = new String[b.countTokens()];
                        for(int j = 0; j< a1.length; j++)
                            a1[i]=a.nextToken();
                        for(int k =0; k<b1.length; k++)
                            b1[i]=b.nextToken();
                        for(int w =0; w<a1.length-1; w++)
                        {
                            if(w == 0)
                                x = Double.parseDouble(a1[w]);
                            if(b1[w].equals("*"))
                            {
                                if(w == 0.0)
                                    o[i] = o[i] * Double.parseDouble(a1[w+1]);
                                else
                                    o[i] = x * Double.parseDouble(a1[w+1]);
                            }
                            else if (b1[w].equals("/"))
                            {
                                if(w == 0.0)
                                    o[i] = o[i] / Double.parseDouble(a1[w+1]);
                                else
                                    o[i] = x / Double.parseDouble(a1[w+1]);
                            }
                            x=0.0;
                            Log.d("MYOUTPUT", "o["+i+"="+o[i]);
                        }
                    }
                    Log.d("MYOUTPUT", ""+o.length);
                    for(int i=0; i<o2.length; i++)
                        o2[i] = order2.nextToken();
                    Log.d("MYOUTPUT", "" + f.length);
                    Log.d("MYOUTPUT", "" + c[0]);
                    Log.d("MYOUTPUT", ""+o[0]);
                    */

                    if ((c.length >= f.length) || output.getText().equals("Error"))
                        output.setText("Error");
                    else {

                        Double out = 0.0;
                        int add = 0;
                        int sub = 0;
                        int mul = 0;
                        int div = 0;
                        int counter = 0;

                        if(f.length==1)
                            out = Double.parseDouble(f[0]);
                        else {
                            for(int i=0; i<f.length-1; i++) {
                                String temp = c[i];
                                String temp2 = f[i+1];
                                if (c[i].equals("*")) {
                                    c[i] = c[counter];
                                    c[counter] = temp;
                                    f[i+1] = f[counter];
                                    f[counter] = temp2;
                                    counter++;
                                }
                            }
                            for(int i=0; i<f.length-1; i++) {
                                String temp = c[i];
                                String temp2 = f[i+1];
                                if (c[i].equals("/")) {
                                    c[i] = c[counter];
                                    c[counter] = temp;
                                    f[i+1] = f[counter];
                                    f[counter] = temp2;
                                    counter++;
                                }
                            }
                            for(int i=0; i<f.length; i++)
                                Log.d("F", ""+f[i]);
                            for(int i=0; i<c.length; i++)
                                Log.d("C", ""+c[i]);
                            for(int i=0; i<f.length-1; i++)
                            {
                                    if (i == 0)
                                        x = Double.parseDouble(f[i]);
                                    if (c.length == 0) {
                                        out = Double.parseDouble(f[i]);

                                    } else if (c[i].equals("+")) {
                                        out = x + out + Double.parseDouble(f[i + 1]);
                                    } else if (c[i].equals("*")) {
                                        if (x == 0.0) {
                                            out = out * Double.parseDouble(f[i + 1]);
                                        } else
                                            out = x * Double.parseDouble(f[i + 1]);
                                    } else if (c[i].equals("/")) {
                                        if (x == 0.0)
                                            out = out / Double.parseDouble(f[i + 1]);
                                        else
                                            out = x / Double.parseDouble(f[i + 1]);
                                    }
                                    x = 0.0;
                                }
                            }
                        if (Double.isInfinite(out))
                            output.setText("Error");
                        else
                            output.setText(Double.toString(out));
                        }
                        Log.d("MYOUTPUT", ""+c.length);
                        Log.d("MYOUTPUT", ""+f.length);


                        //for(int i=0; i<check.countTokens()+1; i++)
                        //{
                        //if(check.nextToken().equals("+")) {
                        //        int x = Integer.parseInt(function.nextToken());
                        //        function = new StringTokenizer(((String) output.getText()).substring(((String) output.getText()).indexOf(function.nextToken())), "+-*
                        //        out = out + x + (Integer.parseInt(function.nextToken()));
                        //    }
                        //}
                        //output.setText(out);*/


                    }
                }
            });



    }


    public void onClick(View v) {
        if(output.getText().equals("Error")) {
            Button b = (Button) v;
            output.setText(b.getText());
        }
        else{
            Button b = (Button) v;
            output.setText((String) output.getText() + b.getText());
        }
    }
}

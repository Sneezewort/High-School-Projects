package com.example.jsondemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.id_textview);

        JSONObject schoolInfos = new JSONObject();
        try {
            schoolInfos.put("name", "Melvin Rajendran");
            schoolInfos.put("id", 10014414);
        } catch (JSONException e) {
            Log.d("TAG", e.toString());
        }

        Log.d("TAG", schoolInfos.toString());

        JSONObject course_cs = new JSONObject();
        try {
            course_cs.put("raw", 98);
            course_cs.put("grade", "A");
            course_cs.put("name", "AP CS");
            schoolInfos.put("Block 1", course_cs);
        } catch (JSONException e) {
            Log.d("TAG", e.toString());
        }

        Log.d("TAG", schoolInfos.toString());

        //Make sure you enter the proper key here. This is the first error many people make.
        try {
            Log.d("TAG", schoolInfos.getJSONObject("Block 1").getString("name"));
        } catch (JSONException e) {
            Log.d("TAG", e.toString());
        }
    }
}

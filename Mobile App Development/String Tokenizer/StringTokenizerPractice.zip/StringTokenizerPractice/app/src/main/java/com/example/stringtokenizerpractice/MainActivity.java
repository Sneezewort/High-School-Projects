package com.example.stringtokenizerpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    TextView sentence;

    TextView textOne;
    TextView textTwo;
    TextView textThree;
    TextView textFour;
    TextView textFive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sentence = findViewById(R.id.id_text_sentence);
        textOne = findViewById(R.id.id_text_one);
        textTwo = findViewById(R.id.id_text_two);
        textThree = findViewById(R.id.id_text_three);
        textFour = findViewById(R.id.id_text_four);
        textFive = findViewById(R.id.id_text_five);

        //0
        String text = "Peter Parker was bit by a radioactive spider.  He gained multiple superpowers: wall-climbing, web-slinging, and spider-sense.";
        sentence.setText(text);

        //1
        StringTokenizer tokenizer = new StringTokenizer(text);
        int punc = 0;
        for (int i = 0; i < tokenizer.countTokens(); i++) {
            for (int j = 0; j < tokenizer.nextToken().length(); j++) {
                if (tokenizer.nextToken().substring(j, j + 1).equals(".") || tokenizer.nextToken().substring(j, j + 1).equals(",") || tokenizer.nextToken().substring(j, j + 1).equals("-") || tokenizer.nextToken().substring(j, j + 1).equals(":"))
                    punc++;
            }
        }
        textOne.setText("There are " + punc + "punctuation marks.");

        //2
        tokenizer = new StringTokenizer(text, ".");
        int sent = tokenizer.countTokens();
        textTwo.setText("There are " + sent + " sentences.");

        //3
        tokenizer = new StringTokenizer(text);
        int words = tokenizer.countTokens();
        textThree.setText("There are " + words + " words.");

        //4


        //5


    }
}

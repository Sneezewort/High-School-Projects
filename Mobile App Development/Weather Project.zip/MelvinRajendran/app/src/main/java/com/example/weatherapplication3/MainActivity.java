package com.example.weatherapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {
    EditText searchEditText;

    ImageView currentConditionImage;
    TextView currentTemperatureText;
    TextView currentMaxText;
    TextView currentMinText;
    TextView currentCityText;
    TextView currentQuoteText;

    TextView hour0Text;
    TextView hour3Text;
    TextView hour6Text;
    TextView hour9Text;
    TextView hour12Text;
    TextView hour15Text;
    TextView hour18Text;
    TextView hour21Text;

    ImageView hour0ConditionImage;
    ImageView hour3ConditionImage;
    ImageView hour6ConditionImage;
    ImageView hour9ConditionImage;
    ImageView hour12ConditionImage;
    ImageView hour15ConditionImage;
    ImageView hour18ConditionImage;
    ImageView hour21ConditionImage;

    TextView hour0TemperatureText;
    TextView hour3TemperatureText;
    TextView hour6TemperatureText;
    TextView hour9TemperatureText;
    TextView hour12TemperatureText;
    TextView hour15TemperatureText;
    TextView hour18TemperatureText;
    TextView hour21TemperatureText;

    TextView day0Text;
    TextView day1Text;
    TextView day2Text;
    TextView day3Text;
    TextView day4Text;

    TextView day0RainText;
    TextView day1RainText;
    TextView day2RainText;
    TextView day3RainText;
    TextView day4RainText;

    ImageView day0ConditionImage;
    ImageView day1ConditionImage;
    ImageView day2ConditionImage;
    ImageView day3ConditionImage;
    ImageView day4ConditionImage;

    TextView day0MaxText;
    TextView day1MaxText;
    TextView day2MaxText;
    TextView day3MaxText;
    TextView day4MaxText;

    TextView day0MinText;
    TextView day1MinText;
    TextView day2MinText;
    TextView day3MinText;
    TextView day4MinText;

    ImageButton searchButton;

    String zipCode = "";

    ArrayList<String> quotes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.id_edittext_search);

        currentConditionImage = findViewById(R.id.id_current_imageview_condition);
        currentTemperatureText = findViewById(R.id.id_current_textview_temp);
        currentMaxText = findViewById(R.id.id_current_textview_max);
        currentMinText = findViewById(R.id.id_current_textview_min);
        currentCityText = findViewById(R.id.id_current_textview_city);
        currentQuoteText = findViewById(R.id.id_current_textview_quote);

        hour0Text = findViewById(R.id.id_hour_textview_hour0);
        hour3Text = findViewById(R.id.id_hour_textview_hour3);
        hour6Text = findViewById(R.id.id_hour_textview_hour6);
        hour9Text = findViewById(R.id.id_hour_textview_hour9);
        hour12Text = findViewById(R.id.id_hour_textview_hour12);
        hour15Text = findViewById(R.id.id_hour_textview_hour15);
        hour18Text = findViewById(R.id.id_hour_textview_hour18);
        hour21Text = findViewById(R.id.id_hour_textview_hour21);

        hour0ConditionImage = findViewById(R.id.id_hour_imageview_condition0);
        hour3ConditionImage = findViewById(R.id.id_hour_imageview_condition3);
        hour6ConditionImage = findViewById(R.id.id_hour_imageview_condition6);
        hour9ConditionImage = findViewById(R.id.id_hour_imageview_condition9);
        hour12ConditionImage = findViewById(R.id.id_hour_imageview_condition12);
        hour15ConditionImage = findViewById(R.id.id_hour_imageview_condition15);
        hour18ConditionImage = findViewById(R.id.id_hour_imageview_condition18);
        hour21ConditionImage = findViewById(R.id.id_hour_imageview_condition21);

        hour0TemperatureText = findViewById(R.id.id_hour_textview_temp0);
        hour3TemperatureText = findViewById(R.id.id_hour_textview_temp3);
        hour6TemperatureText = findViewById(R.id.id_hour_textview_temp6);
        hour9TemperatureText = findViewById(R.id.id_hour_textview_temp9);
        hour12TemperatureText = findViewById(R.id.id_hour_textview_temp12);
        hour15TemperatureText = findViewById(R.id.id_hour_textview_temp15);
        hour18TemperatureText = findViewById(R.id.id_hour_textview_temp18);
        hour21TemperatureText = findViewById(R.id.id_hour_textview_temp21);

        day0Text = findViewById(R.id.id_day_textview_day0);
        day1Text = findViewById(R.id.id_day_textview_day1);
        day2Text = findViewById(R.id.id_day_textview_day2);
        day3Text = findViewById(R.id.id_day_textview_day3);
        day4Text = findViewById(R.id.id_day_textview_day4);

        day0RainText = findViewById(R.id.id_day_textview_rain0);
        day1RainText = findViewById(R.id.id_day_textview_rain1);
        day2RainText = findViewById(R.id.id_day_textview_rain2);
        day3RainText = findViewById(R.id.id_day_textview_rain3);
        day4RainText = findViewById(R.id.id_day_textview_rain4);

        day0ConditionImage = findViewById(R.id.id_day_imageview_condition0);
        day1ConditionImage = findViewById(R.id.id_day_imageview_condition1);
        day2ConditionImage = findViewById(R.id.id_day_imageview_condition2);
        day3ConditionImage = findViewById(R.id.id_day_imageview_condition3);
        day4ConditionImage = findViewById(R.id.id_day_imageview_condition4);

        day0MaxText = findViewById(R.id.id_day_textview_max0);
        day1MaxText = findViewById(R.id.id_day_textview_max1);
        day2MaxText = findViewById(R.id.id_day_textview_max2);
        day3MaxText = findViewById(R.id.id_day_textview_max3);
        day4MaxText = findViewById(R.id.id_day_textview_max4);

        day0MinText = findViewById(R.id.id_day_textview_min0);
        day1MinText = findViewById(R.id.id_day_textview_min1);
        day2MinText = findViewById(R.id.id_day_textview_min2);
        day3MinText = findViewById(R.id.id_day_textview_min3);
        day4MinText = findViewById(R.id.id_day_textview_min4);

        searchButton = findViewById(R.id.id_button_search);

        quotes.add("♩ If there's a light in everybody, send out your ray of sunshine. ♩");
        quotes.add("♩ I need to laugh, and when the sun is out, I've got something I can laugh about. ♩");
        quotes.add("♩ Now that it's raining more than ever. Know that we still have each other. ♩");
        quotes.add("♩ My eyes will do the same, if you walk away. Everyday it will rain. ♩");
        quotes.add("♩ And since we've no place to go... Let it snow, let it snow, let it snow. ♩");
        quotes.add("♩ Lights fill the streets, spreading so much cheer. I should be playing in the winter snow. ♩");
        quotes.add("♩ Thunder, feel the thunder. Lightning then the thunder. ♩");
        quotes.add("♩ It's alright, we're doin' fine, fine, fine. Thunderstruck!");
        quotes.add("♩ The sky is gray and white and cloudy. Sometimes I think it's hanging down on me. ♩");
        quotes.add("♩ All you see is strange clouds. Strange clouds, strange clouds. ♩");
        quotes.add("♩ I know faces, but they fade away. Ethereal misty ballet. ♩");
        quotes.add("♩ Fly me to the moon. Let me play among the stars. ♩");
        quotes.add("♩ I know that mood right, oh. Dance in the moonlight. ♩");

        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                zipCode = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AsyncThread backgroundThread = new AsyncThread();
                backgroundThread.execute(zipCode); // String zipCode is explicitly sent to the AsyncTask backgroundTask
            }
        });

        AsyncThread backgroundThread = new AsyncThread();
        backgroundThread.execute("08852"); // change to current device location
    }

    public class AsyncThread extends AsyncTask<String, Void, ArrayList<JSONObject>> {
        @Override
        protected ArrayList<JSONObject> doInBackground(String... strings) {
            String myZipCode = strings[0];

            try {
                // Extracting current weather data from API
                URL currentURL = new URL("http://api.openweathermap.org/data/2.5/weather?zip=" + myZipCode + "&appid=b2603b678411cbb921d46a20355dc91d&units=imperial");
                URLConnection urlConnection = currentURL.openConnection();
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String totalData = "";
                String lineData;
                while((lineData = bufferedReader.readLine()) != null){
                    totalData += lineData;
                }
                inputStream.close();
                JSONObject currentData = new JSONObject(totalData);

                // Extracting 5-day (3-hour intervals) weather data from API
                URL hourlyURL = new URL("http://api.openweathermap.org/data/2.5/forecast?zip=" + myZipCode + "&appid=b2603b678411cbb921d46a20355dc91d&units=imperial");
                URLConnection urlConnectionH =  hourlyURL.openConnection();
                InputStream inputStreamH = urlConnectionH.getInputStream();
                BufferedReader bufferedReaderH = new BufferedReader(new InputStreamReader(inputStreamH));
                String totalDataH = "";
                String lineDataH = "";
                while((lineDataH = bufferedReaderH.readLine()) != null){
                    totalDataH += lineDataH;
                }
                inputStreamH.close();
                JSONObject hourlyData = new JSONObject(totalDataH);

                ArrayList<JSONObject> list = new ArrayList<>();
                list.add(currentData);
                list.add(hourlyData);

                return list;

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(ArrayList<JSONObject> jsonObjects) {

            try {
                JSONObject current = jsonObjects.get(0);
                JSONObject currentMain = current.getJSONObject("main");
                JSONObject currentWeather = current.getJSONArray("weather").getJSONObject(0);
                //Log.d("TAG", currentMain + "");
                //Log.d("TAG", currentWeather + "");

                currentCityText.setText(jsonObjects.get(0).getString("name"));
                Picasso.get().load("http://openweathermap.org/img/wn/" + currentWeather.getString("icon") + ".png").into(currentConditionImage);
                currentTemperatureText.setText(Math.round(Double.parseDouble(currentMain.get("temp") + "")) + "°");
                currentMaxText.setText(Math.round(Double.parseDouble(currentMain.get("temp_max") + "")) + "°");
                currentMinText.setText(Math.round(Double.parseDouble(currentMain.get("temp_min") + "")) + "°");

                String iconID = currentWeather.getString("icon");
                if (iconID.equals("01d")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2)));
                } else if (iconID.equals("01n")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2) + 11));
                } else if (iconID.equals("02d") || iconID.equals("02n") || iconID.equals("03d") || iconID.equals("03n") || iconID.equals("04d") || iconID.equals("04n")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2) + 8));
                } else if (iconID.equals("09d") || iconID.equals("09n") || iconID.equals("10d") || iconID.equals("10n")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2) + 2));
                } else if (iconID.equals("11d") || iconID.equals("11n")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2) + 6));
                } else if (iconID.equals("13d") || iconID.equals("13n")) {
                    currentQuoteText.setText(quotes.get((int) (Math.random() * 2) + 4));
                } else {
                    currentQuoteText.setText(quotes.get(10));
                }

                JSONObject forecast = jsonObjects.get(1);

                hour0Text.setText("NOW");
                Picasso.get().load("http://openweathermap.org/img/wn/" + currentWeather.getString("icon") + ".png").into(hour0ConditionImage);
                hour0TemperatureText.setText(Math.round(Double.parseDouble(currentMain.get("temp") + "")) + "°");

                for (int i = 0; i < 7; i++) {
                    JSONObject forecastInstance = forecast.getJSONArray("list").getJSONObject(i);
                    //Log.d("TAG", forecastInstance + "");

                    // Hourly time
                    String utcTime = forecastInstance.getString("dt_txt");
                    //Log.d("TAG", utcTime);

                    DateFormat utcFormat = new SimpleDateFormat();
                    TimeZone estTime = TimeZone.getTimeZone("EST");
                    utcFormat.setTimeZone(estTime);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

                    String[] dateTimeArray = utcFormat.format(simpleDateFormat.parse(utcTime)).split(" ");
                    if (dateTimeArray[1].indexOf(":") == 1) {
                        dateTimeArray[1] = dateTimeArray[1].substring(0, 1) + " " + dateTimeArray[2];
                    } else {
                        dateTimeArray[1] = dateTimeArray[1].substring(0, 2) + " " + dateTimeArray[2];
                    }
                    //Log.d("TAG", dateTimeArray[0] + ", " + dateTimeArray[1]);

                    switch (i) {
                        case 0:
                            hour3Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour3ConditionImage);
                            hour3TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 1:
                            hour6Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour6ConditionImage);
                            hour6TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 2:
                            hour9Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour9ConditionImage);
                            hour9TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 3:
                            hour12Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour12ConditionImage);
                            hour12TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 4:
                            hour15Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour15ConditionImage);
                            hour15TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 5:
                            hour18Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour18ConditionImage);
                            hour18TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        case 6:
                            hour21Text.setText(dateTimeArray[1]);
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastInstance.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png").into(hour21ConditionImage);
                            hour21TemperatureText.setText(Math.round(Double.parseDouble(forecastInstance.getJSONObject("main").get("temp") + "")) + "°");
                            break;
                        default:
                            break;
                    }
                }

                // Creating ArrayList containing pertinent JSONObjects for daily forecasts (1:00 PM)
                ArrayList<JSONObject> forecastDataList = new ArrayList<>();
                ArrayList<String> forecastDates = new ArrayList<>();
                ArrayList<String> forecastRain = new ArrayList<>();
                ArrayList<String> forecastConditions = new ArrayList<>();
                ArrayList<String> forecastMax = new ArrayList<>();
                ArrayList<String> forecastMin = new ArrayList<>();

                for (int i = 0; i < 40; i++) {
                    String utcTime = forecast.getJSONArray("list").getJSONObject(i).getString("dt_txt");

                    DateFormat utcFormat = new SimpleDateFormat();
                    TimeZone estTime = TimeZone.getTimeZone("EST");
                    utcFormat.setTimeZone(estTime);
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

                    String temp = utcFormat.format(simpleDateFormat.parse(utcTime));
                    if ((temp.split(" ")[1] + " " + temp.split(" ")[2]).equals("1:00 PM")) {
                        forecastDataList.add(forecast.getJSONArray("list").getJSONObject(i));
                        forecastDates.add(temp.split(" ")[0].split("/")[0] + "/" + temp.split(" ")[0].split("/")[1]);

                        //rain
                        if (forecast.getJSONArray("list").getJSONObject(i).has("rain")) {
                                if (forecast.getJSONArray("list").getJSONObject(i).getJSONObject("rain").has("1h")) {
                                    forecastRain.add(forecast.getJSONArray("list").getJSONObject(i).getJSONObject("rain").get("1h") + " mm");
                                } else if (forecast.getJSONArray("list").getJSONObject(i).getJSONObject("rain").has("3h")) {
                                    forecastRain.add(forecast.getJSONArray("list").getJSONObject(i).getJSONObject("rain").get("3h") + " mm");
                                }
                            } else {
                                forecastRain.add("0 mm");
                        }

                        String max =forecast.getJSONArray("list").getJSONObject(i).getJSONObject("main").get("temp_max").toString();
                        Log.d("TAG", max);
                        forecastConditions.add(forecast.getJSONArray("list").getJSONObject(i).getJSONArray("weather").getJSONObject(0).getString("icon"));
                        forecastMax.add(forecast.getJSONArray("list").getJSONObject(i).getJSONObject("main").get("temp_max").toString() + "°");
                        forecastMin.add(forecast.getJSONArray("list").getJSONObject(i).getJSONObject("main").get("temp_min").toString() + "°");
                    }
                    if (forecastDataList.size() >= 5) {
                        break;
                    }
                }
                Log.d("TAG", forecastDataList.size() + "");
                Log.d("TAG", forecastDates + "");
                Log.d("TAG", forecastRain + "");
                Log.d("TAG", forecastConditions + "");
                Log.d("TAG", forecastMax + "");
                Log.d("TAG", forecastMin + "");

                for (int i = 0; i < 5; i++) {
                    switch (i) {
                        case 0:
                            day0Text.setText(forecastDates.get(i));
                            day0RainText.setText(forecastRain.get(i));
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastConditions.get(i) + ".png").into(day0ConditionImage);
                            day0MaxText.setText(forecastMax.get(i));
                            day0MinText.setText(forecastMin.get(i));
                            break;
                        case 1:
                            day1Text.setText(forecastDates.get(i));
                            day1RainText.setText(forecastRain.get(i));
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastConditions.get(i) + ".png").into(day1ConditionImage);
                            day1MaxText.setText(forecastMax.get(i));
                            day1MinText.setText(forecastMin.get(i));
                            break;
                        case 2:
                            day2Text.setText(forecastDates.get(i));
                            day2RainText.setText(forecastRain.get(i));
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastConditions.get(i) + ".png").into(day2ConditionImage);
                            day2MaxText.setText(forecastMax.get(i));
                            day2MinText.setText(forecastMin.get(i));
                            break;
                        case 3:
                            day3Text.setText(forecastDates.get(i));
                            day3RainText.setText(forecastRain.get(i));
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastConditions.get(i) + ".png").into(day3ConditionImage);
                            day3MaxText.setText(forecastMax.get(i));
                            day3MinText.setText(forecastMin.get(i));
                            break;
                        case 4:
                            day4Text.setText(forecastDates.get(i));
                            day4RainText.setText(forecastRain.get(i));
                            Picasso.get().load("http://openweathermap.org/img/wn/" + forecastConditions.get(i) + ".png").into(day4ConditionImage);
                            day4MaxText.setText(forecastMax.get(i));
                            day4MinText.setText(forecastMin.get(i));
                            break;
                        default:
                            break;
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

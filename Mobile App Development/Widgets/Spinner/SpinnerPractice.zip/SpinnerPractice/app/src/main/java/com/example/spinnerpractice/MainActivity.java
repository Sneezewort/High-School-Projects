package com.example.spinnerpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner prefixSpinner;
    Spinner namesSpinner;
    EditText nameEditText;
    Button addButton;
    TextView previewText;

    ArrayList<String> prefixList;
    ArrayList<String> nameList;

    String currentPrefix = "";
    String currentName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefixSpinner = findViewById(R.id.id_spinner_prefix);
        namesSpinner = findViewById(R.id.id_spinner_names);
        nameEditText = findViewById(R.id.id_edittext_name);
        addButton = findViewById(R.id.id_button_add);
        previewText = findViewById(R.id.id_textview_preview);

        prefixList = new ArrayList<>();
        prefixList.add("Good Boy");
        prefixList.add("Bad Guy");
        prefixList.add("Swell");

        ArrayAdapter<String> prefixAdapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, prefixList);
        prefixSpinner.setAdapter(prefixAdapter);

        prefixSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentPrefix = prefixList.get(position);
                previewText.setText(currentPrefix + " " + currentName);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        nameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                currentName = s.toString();
                previewText.setText(currentPrefix + " " + currentName);
            }
        });


    }
}

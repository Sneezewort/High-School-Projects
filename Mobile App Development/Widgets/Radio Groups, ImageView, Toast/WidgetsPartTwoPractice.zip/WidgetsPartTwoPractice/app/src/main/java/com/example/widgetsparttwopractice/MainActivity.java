package com.example.widgetsparttwopractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup group;
    ImageView image;
    Toast myToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        group = findViewById(R.id.id_radiogroup);
        image = findViewById(R.id.id_imageview);
        myToast = Toast.makeText(MainActivity.this, "blank", Toast.LENGTH_SHORT);

        image.setImageResource(R.drawable.harrypotterlogo);

        group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.id_radiobutton_harry:
                        image.setImageResource(R.drawable.harrypotter);
                        myToast.setText("You have selected Harry Potter!");
                        myToast.show();
                        break;
                    case R.id.id_radiobutton_hermione:
                        image.setImageResource(R.drawable.hermionegranger);
                        myToast.setText("You have selected Hermione Granger!");
                        myToast.show();
                        break;
                    case R.id.id_radiobutton_ron:
                        image.setImageResource(R.drawable.ronweasley);
                        myToast.setText("You have selected Ron Weasley!");
                        myToast.show();
                        break;
                }
            }
        });
    }
}
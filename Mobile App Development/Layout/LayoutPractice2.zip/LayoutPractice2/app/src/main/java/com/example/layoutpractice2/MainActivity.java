package com.example.layoutpractice2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    Button redButton;
    Button blueButton;
    Button greenButton;
    Button cyanButton;
    Button grayButton;
    Button magentaButton;

    LinearLayout verticalLayout;
    LinearLayout horizontalLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        redButton = findViewById(R.id.id_red_button);
        blueButton = findViewById(R.id.id_blue_button);
        greenButton = findViewById(R.id.id_green_button);
        cyanButton = findViewById(R.id.id_cyan_button);
        grayButton = findViewById(R.id.id_gray_button);
        magentaButton = findViewById(R.id.id_magenta_button);

        verticalLayout = findViewById(R.id.id_vertical_linear_layout);
        horizontalLayout = findViewById(R.id.id_horizontal_linear_layout);

        redButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cyanButton.setTextColor(Color.RED);
                grayButton.setTextColor(Color.RED);
                magentaButton.setTextColor(Color.RED);
            }
        });

        blueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cyanButton.setTextColor(Color.BLUE);
                grayButton.setTextColor(Color.BLUE);
                magentaButton.setTextColor(Color.BLUE);
            }
        });

        greenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cyanButton.setTextColor(Color.GREEN);
                grayButton.setTextColor(Color.GREEN);
                magentaButton.setTextColor(Color.GREEN);
            }
        });

        cyanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verticalLayout.setBackgroundColor(Color.CYAN);
            }
        });

        grayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verticalLayout.setBackgroundColor(Color.GRAY);
            }
        });

        magentaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verticalLayout.setBackgroundColor(Color.MAGENTA);
            }
        });
    }
}

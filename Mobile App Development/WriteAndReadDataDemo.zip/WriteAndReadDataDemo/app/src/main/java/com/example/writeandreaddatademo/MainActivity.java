package com.example.writeandreaddatademo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File file = new File("/Users/melvinrajendran/Desktop");
        String dataToWrite = "Hello World!";

        OutputStreamWriter writer;
        try {
            writer = new OutputStreamWriter(openFileOutput(file.getName(), Context.MODE_PRIVATE));
            writer.write(dataToWrite);
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(openFileInput(file.getName())));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            String lineContent = reader.readLine();
            while (lineContent != null) {
                Log.d("TAG", lineContent);
                lineContent = reader.readLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            }
            catch (IOException ioe) {
                System.out.println("Error in closing the BufferedReader");
            }
        }
    }
}